***THE UNOFFICIAL SCHOOL WEBSITE***
*By Ooreoluwa Kalejaiye*
/***
Yea so this was basically all I could come up with XD
***/
*************FOR:BECK JUNIOR HIGH***************
I will be updating this from time to time as I get more experienced in my code. The information here won't be accurate that much(coming from a 6th grader);
The most challenging part was getting the images for alot of the image-filled things.
***@TODO LIST ***
@make login page-done;
@remove login page(to view the site)-almost done
@site layout-undone
@get the images-onto that
@take big breaks-COUNT ON THAT!!
@add site info-undone
@add system help-might not do that(undone)
@design navigation-undone
@make nav items clickable-undone
@try to make scroll images-undon(might not do)
**NOTE:***
***I will also be updating the todo list i i ever think of adding something***
***COPYRIGHT @Ooreoluwa Kalejaiye _______(year I finish(probs 2021))***
All code here is the owner's and shall not be used by anyone who is not a member of Beck. All code is made available under the MIT liscence of the site.