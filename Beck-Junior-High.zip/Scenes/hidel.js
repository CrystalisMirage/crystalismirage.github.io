function hideI(){
  scene="spam";
  i.hide();
  c.hide();
  b.hide();
  h.hide();
var f=createP("15 men on the dead man's chest");
f.style("color","green");
f.position(50,500);
discl=createElement("h1","HOWDY "+i.value()+"!"+"\nIT's DANIEL HERE. THIS WEBISTE ISN'T FINISHED yet SO IF YOU WANT TO SEE THE REST JUST RELOAD YOUR PAGE EVERY 5 MINUTES");
bounce+=5*sin(frameCount+7);
discl.position(0,bounce);
bounce+=5*sin(frameCount+7);
f.show();
dc2.show();
dc2.style("border","25px ridge gold");
dc2.background(255,255,255);
textSize(27);
textAlign(CENTER,CENTER);
text("IF your tired of waitin',\n Go to this site and play one of my games:\nhttps://www.khanacademy.org/profile/orkale9/projects",width/2,width/2);
}