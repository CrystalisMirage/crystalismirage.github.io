function login(){
  c.background(255,255,255);
  textSize(33);
  textAlign(CENTER);
  fill(142,35,4);

  text("Your name is "+i.value()+" ?",width/2.5,height/3.55);
  b.mousePressed(hideI);
  b.style("background-image","url(Images/school.jpeg)");
  b.style("background-size","130px");
  b.style("color","#8e2304");
  image(dgl,0,270,150,130);
  c.style("border","15px ridge #8e2304");
image(tm,400,-10,200,100);
  
  //b.style("font","Trebuchet MS");
 // c.style("border","15px,ridge,#a14411");
}