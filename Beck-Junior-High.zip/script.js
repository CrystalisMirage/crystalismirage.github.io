var i;
var p;
var b;
var t;
var c;
var h;
var tm;
var dgl;
var discl;
var bounce=0;
var dc2;
var scene="login";
function setup(){
dc2=createCanvas(400,400);
dc2.addClass("drctFn");
dc2.hide();
    tm=loadImage('Images/dlo.jpg');
   dgl=loadImage('Images/bulldog.png');
  h=createElement("h1","Log In");
  //h.style("margin-left","150px");
  h.addClass("logH");
c=createCanvas(600,400);
c.show();
  c.position(350,150);
  i=createInput("Type Name here");
  i.position(550,300);
  i.mousePressed(i.value(""));
 p=createP();
p.position(500,650);
p.html(i.value());
b=createButton("Yes,that's my name.");
b.position(600,325);
print(dc2);
}
function draw(){
  switch(scene){
 case"login":   
login();
break;
case "spam":
//backg();
break;
  }
}