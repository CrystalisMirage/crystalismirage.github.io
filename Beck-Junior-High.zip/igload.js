function imgL(image){
  var bload=loadImage(image);
}